package com.example.exemploactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class CadastroAlunoActivity extends AppCompatActivity {

    private Button btSalvar;
    private EditText edRaAluno;
    private EditText edNomeAluno;
    private TextView tvListaAluno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_aluno);


        edRaAluno = findViewById(R.id.edRaAluno);
        tvListaAluno = findViewById(R.id.tvListaAluno);
        edNomeAluno = findViewById(R.id.edNomeAluno);
        btSalvar = findViewById(R.id.btSalvar);
        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarAluno();
            }
        });

        atualizaLista();

    }

    private void salvarAluno() {
        int ra;
        if ((edRaAluno.getText().toString().isEmpty())) {
            edRaAluno.setError("O RA do Aluno deve ser informado!!");
            return;
        } else {
            try {
                ra = Integer.parseInt(edRaAluno.getText().toString());
            } catch (Exception ex) {
                edRaAluno.setError("Selecione um RA válido (somente números)");
            }
        }

        if (edNomeAluno.getText().toString().isEmpty()) {
            edNomeAluno.setError("O nome do Aluno deve ser informado");
            return;
        }
        Aluno aluno = new Aluno();
        aluno.setRa(ra);
        aluno.setNome(edNomeAluno.getText().toString());

        controller.getInstancia().salvarAluno(aluno);

        Toast.makeText((CadastroAlunoActivity.this,
                "Aluno Cadastrado com sucesso!!!", Toast.LENGTH_LONG).show();)

        finish();

    }
    private void atualizaLista(){
        String texto = "";
        ArrayList<Aluno> lista = controller.getInstancia().retornarAlunos();
        for (Aluno aluno: lista){
            texto += aluno.getRa()+" - "+aluno.getNome()+"\n";
        }
        tvListaAluno.setText((texto));
    }
}