package com.example.exemploactivity;

import java.util.ArrayList;

public class controller  {
    private static controller instancia;
    private ArrayList<Aluno> listaAlunos;

    public static controller getInstancia(){
        if(instancia == null) {
            return instancia = new controller();
        }else{
            return instancia;
        }
    }

    private controller(){
        listaAlunos = new ArrayList<>();
    }

    public void salvarAluno(Aluno aluno){
        listaAlunos.add(aluno);
    }

    public ArrayList<Aluno> retornarAlunos() {
        return listaAlunos;
    }
}
